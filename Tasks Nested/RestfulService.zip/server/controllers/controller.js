const {ApiModel} = require( '../models/model' );

const Controller = {
    index : function( request, response ){
        ApiModel
            .getTasks()
            .then (data => {
                response.json(data);
            })
            .catch(error => {
                response.json( error );
            }); 
    },

    new : function( request, response ){
        
        // let newTask = {
        //     title : request.body.title,
        //     description : request.body.description,
        //     completed : request.body.completed
        // };
        console.log(request.query);
        ApiModel
            .createTask(request.body)
            .then(data => {
                response.json(data);
            })
            .catch(error => {
                console.log("NO DATA");
                response.json(error);
            }); 
    },

    remove : function( request, response ){
        ApiModel
            .remove(request.params.id)
            .then(data => {
                response.json(data);
            })
            .catch(error => {
                response.json( "Task might not exist" );
            }); 
    },

    getOne : function( request, response ){
        // console.log(request.params.id);
        ApiModel
            .getOneTask(request.params.id)
            .then(data => {
                response.json(data);
            })
            .catch(error => {
                response.json( "Task does not exist" );
            }); 
    },

    update : function( request, response ){
        
        let newTask = {
            title : request.body.title,
            description : request.body.description,
            completed : request.body.completed
        };

        let id = request.params.id;

        ApiModel
            .updateTask(id, newTask)
            .then(data => {
                response.json(data);
            })
            .catch(error => {
                response.json( "Task might not exist" );
            }); 
    },

}


module.exports = { Controller };

