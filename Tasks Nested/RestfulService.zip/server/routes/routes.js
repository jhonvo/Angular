const express = require ('express');
const Router = express.Router();
const {Controller} = require( '../controllers/controller' );

Router
    .get( '/tasks', Controller.index);

Router
    .post( '/tasks', Controller.new);

Router
    .put( '/tasks/:id', Controller.update);

Router
    .delete( '/tasks/:id', Controller.remove );

Router
    .get( '/tasks/:id', Controller.getOne );

module.exports = {Router};