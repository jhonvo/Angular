const mongoose = require( 'mongoose' );

const TaskSchema = new mongoose.Schema({
    title : {
        type : String,
        required: true
    },
    
    description : {
        type : String,
        default : ""
    },
    
    completed : {
        type : String,
        default : false
    }
    
}, {timestamps: true });

const ApiTask = mongoose.model( 'task', TaskSchema);

const ApiModel = {
    
    getTasks : function(){
        return ApiTask.find().sort({createdAt:-1});
    },
    
    createTask : function(newTask){
        return ApiTask.create(newTask);
    },

    remove : function(id){
        return ApiTask.deleteOne({_id:id});
    },

    updateTask : function(id, newInfo){
        // console.log("THIS IS THE IFNO", newInfo);
        return ApiTask.updateOne({_id:id}, newInfo);
    },

    getOneTask : function(id){
        return ApiTask.find({_id:id});
    }

};

module.exports = {ApiModel};